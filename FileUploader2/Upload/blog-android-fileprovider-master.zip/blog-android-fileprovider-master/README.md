This is a sample project for the article "Get rid of WRITE_EXTERNAL_STORAGE permission with FileProvider" posted on Drivy's blog.

[http://drivy.engineering/android-fileprovider/](http://drivy.engineering/android-fileprovider/)